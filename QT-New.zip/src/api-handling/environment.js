export const environment = {
    apiUrl: 'https://qt.quaidtech.net/'
}